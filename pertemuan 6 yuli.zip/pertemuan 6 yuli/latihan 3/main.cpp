#include <iostream>
#include <vector>

using namespace std;

typedef vector<vector<int>> Matriks;

int jumlahElemenMatriks(const Matriks& matriks) {
    int jumlah = 0;
    for (const auto& baris : matriks) {
        for (const auto& elemen : baris) {
            jumlah += elemen;
        }
    }
    return jumlah;
}

int main() {
    int baris, kolom;

    // Meminta input ukuran matriks
    cout << "Masukkan jumlah baris: ";
    cin >> baris;
    cout << "Masukkan jumlah kolom: ";
    cin >> kolom;

    // Inisialisasi matriks
    Matriks matriks(baris, vector<int>(kolom));

    // Memasukkan elemen matriks
    cout << "Masukkan elemen-elemen matriks:\n";
    for (int i = 0; i < baris; ++i) {
        for (int j = 0; j < kolom; ++j) {
            cout << "Elemen [" << i + 1 << "][" << j + 1 << "]: ";
            cin >> matriks[i][j];
        }
    }

    // Menampilkan matriks
    cout << "\nMatriks yang dimasukkan:\n";
    for (const auto& baris : matriks) {
        for (const auto& elemen : baris) {
            cout << elemen << " ";
        }
        cout << endl;
    }

    // Menghitung jumlah elemen matriks
    int total = jumlahElemenMatriks(matriks);
    cout << "\nJumlah semua elemen dalam matriks: " << total << endl;

    return 0;
}