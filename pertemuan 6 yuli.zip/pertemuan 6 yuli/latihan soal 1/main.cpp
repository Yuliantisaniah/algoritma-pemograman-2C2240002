#include <iostream>
using namespace std;

int main() {
    int N ; //berat badan

    cout<<"masukkan berat badan atlet";
    cin>>N ;

    if(N<= 45) {
        cout<<"tidak memenuhi kualifikasi";
    
    return 1;
}

       if(N <= 50) {
           cout<<"kelas a";
       }
       else if(N <= 55) {
           cout <<"kelas b";
       }
       else if (N <= 60) {
        cout<<"kelas c";
        }
       else if (N <= 65 ) {
            cout<<"kelas d";
        }
       else if (N <= 70) {
           cout<<"kelas e";
       }
       else {
           cout<<"kelas f";
       }

    return 0;
}
